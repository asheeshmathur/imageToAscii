import GuiPart as gui
import processing as prcs

gui.asciiArt()
# prcs.covertImageToAscii()

# aimg = prcs.covertImageToAscii("Dog.jpg", "B", 80, scale)
